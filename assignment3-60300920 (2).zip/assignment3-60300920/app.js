const express = require('express');
const { engine } = require('express-handlebars');

const business = require('./business');
const persistence = require('./persistence');

const app = express();

app.engine('handlebars', engine());
app.set('view engine', 'handlebars');
app.set('views', './views');

app.use(express.urlencoded({ extended: false }));

/**
 * shows list of all employees.
 * @param {Object} req 
 * @param {Object} res 
 * @returns {Promise<void>}
 */
app.get('/', async (req, res) => {
  const employees = await business.getAllEmployees();
  res.render('home', { employees });
});

/**
 * Employee details page.
 * @param {Object} req 
 * @param {Object} res 
 * @returns {Promise<void>}
 */
app.get('/employee/:id', async (req, res) => {
  const employeeId = req.params.id;

  const employee = await business.getEmployeeById(employeeId);
  if (employee === null) {
    res.send('Employee not found');
    return;
  }

  const schedule = await business.getEmployeeSchedule(employeeId);

  // Sort shifts by date then start time 
  for (let i = 0; i < schedule.length - 1; i++) {
    for (let j = 0; j < schedule.length - i - 1; j++) {
      const a = schedule[j].date + schedule[j].startTime;
      const b = schedule[j + 1].date + schedule[j + 1].startTime;
      if (a > b) {
        const temp = schedule[j];
        schedule[j] = schedule[j + 1];
        schedule[j + 1] = temp;
      }
    }
  }

  // Mark shifts before 12:00 as morning 
  for (let i = 0; i < schedule.length; i++) {
    const hour = parseInt(schedule[i].startTime.split(':')[0]);
    if (hour < 12) {
      schedule[i].isMorning = true;
    }
  }

  res.render('employee', { employee, schedule });
});

/**
 * Edit employee form - GET.
 * @param {Object} req 
 * @param {Object} res 
 * @returns {Promise<void>}
 */
app.get('/employee/:id/edit', async (req, res) => {
  const employeeId = req.params.id;

  const employee = await business.getEmployeeById(employeeId);
  if (employee === null) {
    res.send('Employee not found');
    return;
  }

  res.render('edit', { employee });
});

/**
 * Edit employee form - POST 
 * @param {Object} res 
 * @returns {Promise<void>}
 */
app.post('/employee/:id/edit', async (req, res) => {
  const employeeId = req.params.id;

  const name = (req.body.name || '').trim();
  const phone = (req.body.phone || '').trim();

  if (name === '') {
    res.send('Name cannot be empty');
    return;
  }

  const phoneRegex = /^\d{4}-\d{4}$/;
  if (!phoneRegex.test(phone)) {
    res.send('Phone number must be in the format ####-####');
    return;
  }

  await persistence.updateEmployee(employeeId, name, phone);

  // PRG cycle: redirect after POST
  res.redirect('/');
});

/**
 * Starts the server after connecting to MongoDB.
 * @returns {Promise<void>}
 */
async function main() {
  await persistence.connect();
  app.listen(3000, () => {
    console.log('Server running on localhost:3000');
  });
}

main();
