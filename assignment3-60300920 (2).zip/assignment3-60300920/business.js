const persistence = require('./persistence');

/**
 * Computes the duration of a shift in hours.
 * For example: 11:00 to 13:30 is 2.5 hours.
 *
 * @param {string} startTime
 * @param {string} endTime
 * @returns {number}
 */
function computeShiftDuration(startTime, endTime) {
  const startParts = startTime.split(':');
  const endParts = endTime.split(':');

  const startHours = Number(startParts[0]);
  const startMinutes = Number(startParts[1]);
  const endHours = Number(endParts[0]);
  const endMinutes = Number(endParts[1]);

  const startTotal = startHours + (startMinutes / 60);
  const endTotal = endHours + (endMinutes / 60);

  return endTotal - startTotal;
}

/**
 * Get all employees.
 * @returns {Promise<Array>}
 */
async function getAllEmployees() {
  return await persistence.getEmployees();
}

/**
 * Get a single employee by ID.
 * @param {string} employeeId
 * @returns {Promise<Object|null>}
 */
async function getEmployeeById(employeeId) {
  return await persistence.findEmployeeById(employeeId);
}

/**
 * Add a new employee to the system.
 * Generates the next employeeId (E###).
 *
 * @param {string} name
 * @param {string} phone
 * @returns {Promise<string>}
 */
async function addEmployee(name, phone) {
  const employees = await persistence.getEmployees();

  let highestId = 0;
  for (let i = 0; i < employees.length; i++) {
    const idNum = parseInt(employees[i].employeeId.slice(1));
    if (idNum > highestId) {
      highestId = idNum;
    }
  }

  const newId = 'E' + String(highestId + 1).padStart(3, '0');

  await persistence.saveEmployee({
    employeeId: newId,
    name: name,
    phone: phone
  });

  return 'Employee added successfully';
}

/**
 * Check if an employee exists.
 * @param {string} employeeId
 * @returns {Promise<boolean>}
 */
async function employeeExists(employeeId) {
  const employee = await persistence.findEmployeeById(employeeId);
  return employee !== null;
}

/**
 * Check if a shift exists.
 * @param {string} shiftId
 * @returns {Promise<boolean>}
 */
async function shiftExists(shiftId) {
  const shift = await persistence.findShiftById(shiftId);
  return shift !== null;
}

/**
 * Calculate total hours for an employee on a specific date.
 * @param {string} employeeId
 * @param {string} date
 * @returns {Promise<number>}
 */
async function calculateDailyHours(employeeId, date) {
  const assignments = await persistence.findAssignmentsByEmployeeId(employeeId);

  let totalHours = 0;

  for (let i = 0; i < assignments.length; i++) {
    const shift = await persistence.findShiftById(assignments[i].shiftId);

    if (shift !== null && shift.date === date) {
      totalHours += computeShiftDuration(shift.startTime, shift.endTime);
    }
  }

  return totalHours;
}

/**
 * Get schedule (list of shifts) for a specific employee.
 * @param {string} employeeId
 * @returns {Promise<Array|null>}
 */
async function getEmployeeSchedule(employeeId) {
  const employee = await persistence.findEmployeeById(employeeId);
  if (employee === null) {
    return null;
  }

  const assignments = await persistence.findAssignmentsByEmployeeId(employeeId);
  const result = [];

  for (let i = 0; i < assignments.length; i++) {
    const shift = await persistence.findShiftById(assignments[i].shiftId);
    if (shift !== null) {
      result[result.length] = shift;
    }
  }

  return result;
}

module.exports = {
  computeShiftDuration,
  getAllEmployees,
  getEmployeeById,
  addEmployee,
  getEmployeeSchedule,
  employeeExists,
  shiftExists,
  calculateDailyHours
};
