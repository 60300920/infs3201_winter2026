const { MongoClient } = require('mongodb');
const fs = require('fs/promises');
const{setServers}=
require('node:dns/promises')
setServers(["1.1.1.1","8.8.8.8"])

const DB_NAME = 'infs3201_winter2026';

let db;
let client;

/**
 * Connect to the MongoDB database.
 * @returns {Promise<void>}
 */
async function connect() {
  const uri = process.env.MONGODB_URI || 'mongodb+srv://60300920:Ihavealandcruiser2011@cluster0.uynfqk5.mongodb.net/?appName=Cluster0';
  client = new MongoClient(uri);
  await client.connect();
  db = client.db(DB_NAME);
  console.log(`Connected to MongoDB (${DB_NAME})`);
}

/**
 * Get all employees.
 * @returns {Promise<Array>}
 */
async function getEmployees() {
  return await db.collection('employees').find({}).toArray();
}

/**
 * Save a new employee.
 * @param {Object} employee
 * @returns {Promise<void>}
 */
async function saveEmployee(employee) {
  await db.collection('employees').insertOne(employee);
}

/**
 * Update an employee's name and phone.
 * @param {string} employeeId
 * @param {string} name
 * @param {string} phone
 * @returns {Promise<void>}
 */
async function updateEmployee(employeeId, name, phone) {
  await db.collection('employees').updateOne(
    { employeeId: employeeId },
    { $set: { name: name, phone: phone } }
  );
}

/**
 * Find a single employee by ID.
 * @param {string} employeeId
 * @returns {Promise<Object|null>}
 */
async function findEmployeeById(employeeId) {
  return await db.collection('employees').findOne({ employeeId: employeeId });
}

/**
 * Get all shifts.
 * @returns {Promise<Array>}
 */
async function getShifts() {
  return await db.collection('shifts').find({}).toArray();
}

/**
 * Find a single shift by ID.
 * @param {string} shiftId
 * @returns {Promise<Object|null>}
 */
async function findShiftById(shiftId) {
  return await db.collection('shifts').findOne({ shiftId: shiftId });
}

/**
 * Get all assignments.
 * @returns {Promise<Array>}
 */
async function getAssignments() {
  return await db.collection('assignments').find({}).toArray();
}

/**
 * Find all assignments for a specific employee.
 * @param {string} employeeId
 * @returns {Promise<Array>}
 */
async function findAssignmentsByEmployeeId(employeeId) {
  return await db.collection('assignments').find({ employeeId: employeeId }).toArray();
}

/**
 * Retrieve the config from the JSON file.
 * @returns {Promise<Object>}
 */
async function getConfig() {
  return JSON.parse(await fs.readFile('./config.json', 'utf8'));
}

module.exports = {
  connect,
  getEmployees,
  saveEmployee,
  updateEmployee,
  findEmployeeById,
  getShifts,
  findShiftById,
  getAssignments,
  findAssignmentsByEmployeeId,
  getConfig
};
